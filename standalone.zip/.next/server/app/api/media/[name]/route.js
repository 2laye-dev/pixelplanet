var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/media/[name]/route.js")
R.c("server/chunks/[externals]__1kim36o62rs96._.js")
R.c("server/chunks/_01strfex34kyr._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_0ffpkiu4w2tz3._.js")
R.c("server/chunks/_next-internal_server_app_api_media_[name]_route_actions_1x1oymi5s9e43.js")
R.m(60528)
module.exports=R.m(60528).exports
